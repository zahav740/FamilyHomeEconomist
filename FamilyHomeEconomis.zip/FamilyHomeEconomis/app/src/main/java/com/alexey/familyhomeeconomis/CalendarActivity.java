package com.alexey.familyhomeeconomis;

import androidx.appcompat.app.AppCompatActivity;
import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;

import java.util.Calendar;

public class CalendarActivity extends AppCompatActivity {

    private MaterialCalendarView[] calendarViews = new MaterialCalendarView[12];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        calendarViews[0] = findViewById(R.id.calendarView1);
        // Repeat for each month...
        calendarViews[11] = findViewById(R.id.calendarView12);

        Calendar calendar = Calendar.getInstance();
        for (int i = 0; i < 12; i++) {
            calendar.set(Calendar.MONTH, i);
            calendar.set(Calendar.DAY_OF_MONTH, 1);
            CalendarDay firstDayOfMonth = CalendarDay.from(calendar);

            calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
            CalendarDay lastDayOfMonth = CalendarDay.from(calendar);

            calendarViews[i].state().edit()
                    .setMinimumDate(firstDayOfMonth)
                    .setMaximumDate(lastDayOfMonth)
                    .commit();

            // Setting the selection mode to none
            calendarViews[i].setSelectionMode(MaterialCalendarView.SELECTION_MODE_NONE);
        }
    }
}


